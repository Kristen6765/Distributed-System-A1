rmiregistry -J-Djava.rmi.server.useCodebaseOnly=false 3424 &
