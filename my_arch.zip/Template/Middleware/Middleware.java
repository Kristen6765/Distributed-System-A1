package Server.RMI;
import Server.Interface.*;
import java.util.*;
import java.io.*;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.NotBoundException;
import java.rmi.server.UnicastRemoteObject;
import Server.Interface.*;
import Server.Common.*;

public class RMIMiddleware extends ResourceManager {

    private static String m_serverName ="Middleware";

    private static String m_rmiPrefix = "group_24_";

    private static int middleware_port = 3024;
    private static int server_port_car = 3124; 
    private static int server_port_room = 3224;
     private static int server_port_flight = 3324;

    private static IResourceManager flightRM = null;
    private static IResourceManager carRM = null;
    private static IResourceManager roomRM  = null;

    private Queue<Integer> customerIdx;

    public RMIMiddleware(String name) {
	    super(name);
    }

    public static void main(String args[]) {

        for(int i=0; i<args.length; i++) {
            System.out.println(args[i]);
        }

        // Create the RMI server entry
		try {
			// Create a new Server object
			RMIResourceManager server = new RMIResourceManager(s_serverName);

			// Dynamically generate the stub (client proxy)
			IResourceManager resourceManager = (IResourceManager)UnicastRemoteObject.exportObject(server, 0);

			// Bind the remote object's stub in the registry
			Registry l_registry;
			try {
				l_registry = LocateRegistry.createRegistry(3024);
			} catch (RemoteException e) {
				l_registry = LocateRegistry.getRegistry(3024);
			}
			final Registry registry = l_registry;
			registry.rebind(s_rmiPrefix + s_serverName, resourceManager);

			Runtime.getRuntime().addShutdownHook(new Thread() {
				public void run() {
					try {
						registry.unbind(s_rmiPrefix + s_serverName);
						System.out.println("'" + s_serverName + "' resource manager unbound");
					}
					catch(Exception e) {
						System.err.println((char)27 + "[31;1mServer exception: " + (char)27 + "[0mUncaught exception");
						e.printStackTrace();
					}
				}
			});                                       
			System.out.println("'" + s_serverName + "' resource manager server ready and bound to '" + s_rmiPrefix + s_serverName + "'");
		}
		catch (Exception e) {
			System.err.println((char)27 + "[31;1mServer exception: " + (char)27 + "[0mUncaught exception");
			e.printStackTrace();
			System.exit(1);
		}

            
		try {
			boolean first = true;
			while (true) {
				try {
                    Registry flightRegistry = LocateRegistry.getRegistry(args[0], server_port_flight);
                    flightRM = (IResourceManager) flightRegistry.lookup(m_rmiPrefix + "Flights");
                    System.out.println("Connected to '" +"Flights"  + "' server [" + args[0] + ":" + server_port + "/" + s_rmiPrefix + name + "]");
                    if (flightRM == null)
                        throw new AssertionError();

                    Registry carRegistry = LocateRegistry.getRegistry(args[1], server_port_car);
                    carRM = (IResourceManager) carRegistry.lookup(m_rmiPrefix + "Cars");
                    System.out.println("Connected to '" +"Cars"  + "' server [" + args[1] + ":" + server_port + "/" + s_rmiPrefix + name + "]");
                    if (carRM == null)
                        throw new AssertionError();

                    Registry roomRegistry = LocateRegistry.getRegistry(args[2],server_port_room);
                    roomRM = (IResourceManager) roomRegistry.lookup(m_rmiPrefix + "Rooms");
                     System.out.println("Connected to '" +"Rooms"  + "' server [" + args[1] + ":" + server_port + "/" + s_rmiPrefix + name + "]");
                    if (roomRM == null)
                        throw new AssertionError();



					// Registry registry = LocateRegistry.getRegistry(server, port);
					// m_resourceManager = (IResourceManager)registry.lookup(s_rmiPrefix + name);
					// System.out.println("Connected to '" + name + "' server [" + server + ":" + port + "/" + s_rmiPrefix + name + "]");
					break;
				}
				catch (NotBoundException|RemoteException e) {
					if (first) {
						System.out.println("Waiting for '" + name + "' server [" + server + ":" + port + "/" + s_rmiPrefix + name + "]");
						first = false;
					}
				}
				Thread.sleep(500);
			}
		}
		catch (Exception e) {
			System.err.println((char)27 + "[31;1mServer exception: " + (char)27 + "[0mUncaught exception");
			e.printStackTrace();
			System.exit(1);
		}



  public boolean addFlight(int id, int flightNum, int flightSeats, int flightPrice)
      throws RemoteException {
    return flightRM.addFlight(id, flightNum, flightSeats, flightPrice);
  }

  @Override
  public boolean addCars(int id, String location, int numCars, int price) throws RemoteException {
    return carRM.addCars(id, location, numCars, price);
  }

  @Override
  public boolean addRooms(int id, String location, int numRooms, int price) throws RemoteException {
    return roomRM.addRooms(id, location, numRooms, price);
  }


  @Override
  public boolean deleteFlight(int id, int flightNum) throws RemoteException {
    return flightRM.deleteFlight(id, flightNum);
  }

  @Override
  public boolean deleteCars(int id, String location) throws RemoteException {
    return carRM.deleteCars(id, location);
  }

  @Override
  public boolean deleteRooms(int id, String location) throws RemoteException {
    return roomRM.deleteRooms(id, location);
  }

  @Override
  public boolean deleteCustomer(int id, int customerID) throws RemoteException {
    return flightRM.deleteCustomer(id, customerID) && carRM.deleteCustomer(id, customerID) && roomRM.deleteCustomer(id, customerID);
  }

  @Override
  public int queryFlight(int id, int flightNumber) throws RemoteException {
    return flightRM.queryFlight(id, flightNumber);
  }

  @Override
  public int queryCars(int id, String location) throws RemoteException {
    return carRM.queryCars(id, location);
  }

  @Override
  public int queryRooms(int id, String location) throws RemoteException {
    return roomRM.queryRooms(id, location);
  }

  @Override
  public String queryCustomerInfo(int id, int customerID) throws RemoteException {
    return flightRM.queryCustomerInfo(id, customerID)
        + carRM.queryCustomerInfo(id, customerID).split("/n", 2)[1] + roomRM.queryCustomerInfo(id, customerID).split("/n", 2)[1];
  }

  @Override
  public int queryFlightPrice(int id, int flightNumber) throws RemoteException {
    return flightRM.queryFlightPrice(id, flightNumber);
  }

  @Override
  public int queryCarsPrice(int id, String location) throws RemoteException {
    return carRM.queryCarsPrice(id, location);
  }

  @Override
  public int queryRoomsPrice(int id, String location) throws RemoteException {
    return roomRM.queryRoomsPrice(id, location);
  }

  @Override
  public int newCustomer(int id) throws RemoteException {
    int cid = Collections.max(customerIdx);
    this.newCustomer(id, cid);
    return cid;
  }

  @Override
  public boolean newCustomer(int id, int cid) throws RemoteException {
    this.customerIdx.add(cid);
    return flightRM.newCustomer(id, cid) && carRM.newCustomer(id, cid) && roomRM.newCustomer(id, cid);
  }

  @Override
  public boolean reserveFlight(int id, int customerID, int flightNumber) throws RemoteException {
    return flightRM.reserveFlight(id, customerID, flightNumber);
  }

  @Override
  public boolean reserveCar(int id, int customerID, String location) throws RemoteException {
    return carRM.reserveCar(id, customerID, location);
  }

  @Override
  public boolean reserveRoom(int id, int customerID, String location) throws RemoteException {
    return roomRM.reserveRoom(id, customerID, location);
  }


  @Override
  public boolean bundle(int id, int customerID, Vector<String> flightNumbers, String location,
      boolean car, boolean room) throws RemoteException {
    	boolean res = true;
		for (String fn:flightNumbers) res &=reserveFlight(id,customerID,Integer.parseInt(fn));
		if (car) res &= reserveCar(id, customerID, location);
		if (room) res &= reserveRoom(id, customerID, location);
		return res; // return False if any of the above failed
  }



}
