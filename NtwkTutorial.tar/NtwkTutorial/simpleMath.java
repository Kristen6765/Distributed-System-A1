public class simpleMath
{
	public int mul(int x, int y)
	{ return x*y; }

	public int add(int x, int y)
	{ return x+y; }
}
